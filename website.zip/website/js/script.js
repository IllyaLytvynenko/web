// Main JavaScript for DigiSolutions

document.addEventListener('DOMContentLoaded', function() {
    // Initialize language based on URL parameter or default to Ukrainian
    initializeLanguage();
    
    // Form validation
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            validateContactForm();
        });
    }
    
    // Admin login form validation
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            validateLoginForm();
        });
    }
    
    // Initialize any tooltips
    initializeTooltips();
});

function initializeLanguage() {
    const urlParams = new URLSearchParams(window.location.search);
    const lang = urlParams.get('lang');
    
    if (lang === 'en') {
        // English is already loaded
    } else {
        // Default to Ukrainian
        // Already on Ukrainian page by default
    }
}

function switchLanguage(lang) {
    // Get current page path
    const currentPath = window.location.pathname;
    
    if (lang === 'en') {
        // Switch to English
        if (currentPath.includes('_en.html')) {
            // Already on English page
            return;
        } else if (currentPath.endsWith('.html')) {
            // Get base filename without extension
            const basePath = currentPath.substring(0, currentPath.lastIndexOf('.html'));
            // Redirect to English version
            window.location.href = basePath + '_en.html';
        } else if (currentPath.endsWith('/')) {
            // On a directory index page
            window.location.href = 'index_en.html';
        }
    } else {
        // Switch to Ukrainian
        if (!currentPath.includes('_en.html')) {
            // Already on Ukrainian page
            return;
        } else {
            // Get base filename without _en.html
            const basePath = currentPath.substring(0, currentPath.lastIndexOf('_en.html'));
            // Redirect to Ukrainian version
            window.location.href = basePath + '.html';
        }
    }
}

function validateContactForm() {
    let isValid = true;
    
    // Get form fields
    const name = document.getElementById('name');
    const email = document.getElementById('email');
    const subject = document.getElementById('subject');
    const message = document.getElementById('message');
    
    // Reset error states
    resetFormErrors([name, email, subject, message]);
    
    // Validate name
    if (name.value.trim() === '') {
        setErrorFor(name);
        isValid = false;
    }
    
    // Validate email
    if (email.value.trim() === '' || !isValidEmail(email.value)) {
        setErrorFor(email);
        isValid = false;
    }
    
    // Validate subject
    if (subject.value.trim() === '') {
        setErrorFor(subject);
        isValid = false;
    }
    
    // Validate message
    if (message.value.trim() === '') {
        setErrorFor(message);
        isValid = false;
    }
    
    // If form is valid, show success message
    if (isValid) {
        showFormSuccess();
    }
    
    return isValid;
}

function validateLoginForm() {
    let isValid = true;
    
    // Get form fields
    const username = document.getElementById('username');
    const password = document.getElementById('password');
    
    // Reset error states
    resetFormErrors([username, password]);
    
    // Validate username
    if (username.value.trim() === '') {
        setErrorFor(username);
        isValid = false;
    }
    
    // Validate password
    if (password.value.trim() === '') {
        setErrorFor(password);
        isValid = false;
    }
    
    // If form is valid, simulate login (for demo)
    if (isValid) {
        // Demo admin credentials
        if (username.value === 'admin' && password.value === 'password') {
            window.location.href = 'admin-dashboard.html';
        } else {
            showLoginError();
        }
    }
    
    return isValid;
}

function resetFormErrors(fields) {
    fields.forEach(field => {
        field.classList.remove('is-invalid');
    });
    
    // Hide any alert messages
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        alert.style.display = 'none';
    });
}

function setErrorFor(input) {
    input.classList.add('is-invalid');
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function showFormSuccess() {
    const contactForm = document.getElementById('contactForm');
    const successAlert = document.getElementById('successAlert');
    
    // Reset form
    contactForm.reset();
    
    // Show success message
    successAlert.style.display = 'block';
    
    // Hide success message after 5 seconds
    setTimeout(() => {
        successAlert.style.display = 'none';
    }, 5000);
}

function showLoginError() {
    const errorAlert = document.getElementById('loginError');
    
    // Show error message
    errorAlert.style.display = 'block';
}

function initializeTooltips() {
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Admin panel functions
function deleteItem(id) {
    if (confirm('Are you sure you want to delete this item?')) {
        // In real application, this would make an API call to delete the item
        console.log('Deleting item with ID: ' + id);
        
        // For demo: just hide the row
        const row = document.getElementById('item-' + id);
        if (row) {
            row.style.display = 'none';
        }
    }
}